package com.example.blazeandroid2.androidsample;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.cardview.listview.R;

import java.util.ArrayList;

/**
 * Created by blaze android2 on 9/2/2016.
 */
public class CustomListAdapter extends BaseAdapter {
    private ArrayList<NotificationModel> listData;
    private LayoutInflater layoutInflater;
    ImageLoader imageLoader;
    Context context;

    public CustomListAdapter(Context context, ArrayList<NotificationModel> listData) {
        this.listData = listData;
        this.context=context;
        layoutInflater = LayoutInflater.from(context);
        imageLoader=new ImageLoader(context.getApplicationContext());
    }

    @Override
    public int getCount() {
        return listData.size();
    }

    @Override
    public Object getItem(int position) {
        return listData.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            convertView = layoutInflater.inflate(R.layout.row_listview_item, null);
            holder = new ViewHolder();
            holder.title = (TextView) convertView.findViewById(R.id.title);
            holder.message = (TextView) convertView.findViewById(R.id.message);
            holder.starttdate = (TextView) convertView.findViewById(R.id.startdate);
            holder.enddate = (TextView) convertView.findViewById(R.id.enddate);
            holder.imageView = (ImageView) convertView.findViewById(R.id.imageView);
            convertView.setTag(holder);
        } else {
            holder = (ViewHolder) convertView.getTag();
        }


        NotificationModel notificationModel=listData.get(position);

        imageLoader.DisplayImage(notificationModel.getImg_link(), holder.imageView);


        return convertView;
    }

    static class ViewHolder {
        TextView title;
        TextView message;
        TextView starttdate,enddate;
        ImageView imageView;
    }
}
