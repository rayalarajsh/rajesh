package com.example.blazeandroid2.androidsample;

import android.app.ProgressDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;
import com.cardview.listview.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    static final String url = "http://api.androidhive.info/json/movies.json";
    CustomListAdapter customListAdapter;
    ArrayList<NotificationModel> movieList = new ArrayList<NotificationModel>();
    private ProgressDialog pDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView=(ListView)findViewById(R.id.listview);
        customListAdapter=new CustomListAdapter(MainActivity.this,movieList);
        listView.setAdapter(customListAdapter);
        RequestQueue queue = Volley.newRequestQueue(this);
        pDialog = new ProgressDialog(this);
        // Showing progress dialog before making http request
        pDialog.setMessage("Loading...");
        pDialog.show();
        JsonArrayRequest movieReq = new JsonArrayRequest(url,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {

                        pDialog.dismiss();
                        // Parsing json
                        for (int i = 0; i < response.length(); i++) {
                            try {

                                JSONObject obj = response.getJSONObject(i);

                                NotificationModel notificationModel=new NotificationModel();

                                notificationModel.setCreate_date("12-12-2012");
                                notificationModel.setEnd_date("13-12-2016");
                                notificationModel.setId(""+i);
                                notificationModel.setImg_link(obj.getString("image"));
                                notificationModel.setTitle("rajesh");
                                notificationModel.setMessage("rajesh is testing here you cannot to mistakes");



                                // adding movie to movies array
                                movieList.add(notificationModel);

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                        }

                        // notifying list adapter about data changes
                        // so that it renders the list view with updated data
                        customListAdapter.notifyDataSetChanged();
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

pDialog.dismiss();
            }
        });

        queue.add(movieReq);

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        hidePDialog();
    }

    private void hidePDialog() {
        if (pDialog != null) {
            pDialog.dismiss();
            pDialog = null;
        }
    }
}
